import React, { useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore, api } from '../store'
import { GameLogo } from '../components/Icons'
import { IC } from '../components/Icons'
import { RubleAmount } from '../components/RubleDisplay'

const CATS = [
  { id:'all', label:'ВСЁ' },
  { id:'games', label:'ИГРЫ' },
  { id:'software', label:'СОФТ' },
  { id:'social', label:'СОЦСЕТИ' },
  { id:'education', label:'КУРСЫ' },
  { id:'services', label:'УСЛУГИ' },
  { id:'finance', label:'ФИНАНСЫ' },
  { id:'other', label:'ДРУГОЕ' },
]

export default function HomePage() {
  const navigate = useNavigate()
  const { user } = useStore()
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [cat, setCat] = useState('all')
  const [search, setSearch] = useState('')
  const [sort, setSort] = useState('createdAt')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await api.get('/products', {
        params: { category: cat==='all'?undefined:cat, search:search||undefined, sort }
      })
      setProducts(data.products || [])
    } catch {}
    setLoading(false)
  }, [cat, sort, search])

  useEffect(() => { const t = setTimeout(load, search ? 380 : 0); return () => clearTimeout(t) }, [load])

  return (
    <div style={{ minHeight:'100%' }}>
      {/* Header */}
      <div style={{ padding:'12px 14px 0', position:'sticky', top:0, zIndex:50,
        background:'rgba(7,7,9,0.95)', borderBottom:'1px solid rgba(255,102,0,0.12)',
        backdropFilter:'blur(24px)' }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'12px' }}>
          <div>
            <div style={{
              fontFamily:'var(--font-d)', fontSize:'32px', fontWeight:700, letterSpacing:'0.06em',
              background:'linear-gradient(135deg,#ff8800,#ff5500,#ff9900)',
              WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent',
              filter:'drop-shadow(0 0 8px rgba(255,100,0,0.45))',
              animation:'neonPulse 4s ease-in-out infinite', lineHeight:1
            }}>GIVIHUB</div>
            <div style={{ fontSize:'9px', color:'rgba(255,102,0,0.5)', letterSpacing:'0.2em', fontFamily:'var(--font-d)', marginTop:'1px' }}>
              DIGITAL MARKETPLACE
            </div>
          </div>
          {user ? (
            <div onClick={()=>navigate('/wallet')} style={{
              display:'flex', alignItems:'center', gap:'8px',
              padding:'8px 14px', borderRadius:'12px', cursor:'pointer',
              background:'rgba(255,102,0,0.08)',
              border:'1px solid rgba(255,102,0,0.28)',
              boxShadow:'inset 0 1px 0 rgba(255,255,255,0.06), 0 0 12px rgba(255,102,0,0.12)'
            }}>
              <IC.Diamond s={16} c="#ff8833"/>
              <div>
                <div style={{ fontFamily:'var(--font-d)', fontWeight:700, fontSize:'16px', color:'#ff8833',
                  textShadow:'0 0 8px rgba(255,102,0,0.5)', lineHeight:1 }}>
                  ${parseFloat(user.balance||0).toFixed(2)}
                </div>
              </div>
            </div>
          ) : (
            <button className="btn btn-primary btn-sm" onClick={()=>navigate('/auth')}
              style={{ fontFamily:'var(--font-d)', letterSpacing:'0.05em', gap:'6px' }}>
              <IC.User s={14} c="white"/> ВОЙТИ
            </button>
          )}
        </div>

        {/* Search */}
        <div style={{ position:'relative', marginBottom:'10px' }}>
          <div style={{ position:'absolute', left:'13px', top:'50%', transform:'translateY(-50%)', pointerEvents:'none', opacity:0.45 }}>
            <IC.Search s={16}/>
          </div>
          <input className="input" style={{ paddingLeft:'40px', paddingRight:search?'38px':'14px', height:'42px', borderRadius:'100px', fontSize:'14px' }}
            placeholder="Поиск товаров..." value={search} onChange={e=>setSearch(e.target.value)}/>
          {search && (
            <button onClick={()=>setSearch('')} style={{ position:'absolute', right:'12px', top:'50%', transform:'translateY(-50%)',
              background:'none', border:'none', color:'var(--text3)', cursor:'pointer', display:'flex', alignItems:'center' }}>
              <IC.X s={16}/>
            </button>
          )}
        </div>

        {/* Category tabs */}
        <div style={{ display:'flex', gap:'5px', overflowX:'auto', scrollbarWidth:'none', paddingBottom:'10px' }}>
          {CATS.map(c => (
            <button key={c.id} onClick={()=>setCat(c.id)} style={{
              padding:'6px 13px', borderRadius:'100px', whiteSpace:'nowrap', cursor:'pointer',
              border:`1px solid ${cat===c.id?'rgba(255,102,0,0.5)':'rgba(255,255,255,0.07)'}`,
              background: cat===c.id?'rgba(255,102,0,0.14)':'rgba(255,255,255,0.03)',
              color: cat===c.id?'#ff8833':'var(--text3)',
              fontFamily:'var(--font-d)', fontWeight:cat===c.id?700:500, fontSize:'12px', letterSpacing:'0.05em',
              boxShadow: cat===c.id?'0 0 10px rgba(255,102,0,0.2),inset 0 1px 0 rgba(255,255,255,0.08)':'inset 0 1px 0 rgba(255,255,255,0.03)',
              transition:'all var(--ease)'
            }}>{c.label}</button>
          ))}
        </div>
      </div>

      {/* Controls */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'8px 14px' }}>
        <span style={{ fontSize:'11px', color:'var(--text3)', fontFamily:'var(--font-d)', letterSpacing:'0.05em' }}>
          {loading ? '...' : `${products.length} ТОВАРОВ`}
        </span>
        <select value={sort} onChange={e=>setSort(e.target.value)} style={{
          background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,102,0,0.18)',
          color:'var(--text2)', padding:'5px 10px', borderRadius:'8px',
          fontSize:'12px', cursor:'pointer', outline:'none', fontFamily:'var(--font-d)' }}>
          <option value="createdAt">НОВЫЕ</option>
          <option value="price_asc">ДЕШЕВЛЕ</option>
          <option value="price_desc">ДОРОЖЕ</option>
          <option value="popular">ПОПУЛЯРНЫЕ</option>
        </select>
      </div>

      <div style={{ padding:'0 10px 16px', display:'grid', gridTemplateColumns:'1fr 1fr', gap:'10px' }}>
        {loading
          ? Array(6).fill(0).map((_,i)=><SkeletonCard key={i} i={i}/>)
          : products.length===0 ? <Empty/>
          : products.map((p,i)=><ProductCard key={p.id} product={p} i={i} onClick={()=>navigate(`/product/${p.id}`)}/>)
        }
      </div>
    </div>
  )
}

function ProductCard({ product, i, onClick }) {
  const [vis, setVis] = useState(false)
  const [hov, setHov] = useState(false)
  useEffect(() => { const t = setTimeout(()=>setVis(true), i*55); return()=>clearTimeout(t) }, [i])
  const price = parseFloat(product.price)
  const seller = product.seller || {}

  return (
    <div onClick={onClick}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{
        borderRadius:'16px', overflow:'hidden', cursor:'pointer',
        background:'rgba(11,11,15,0.92)',
        border:`1px solid ${hov?'rgba(255,102,0,0.45)':'rgba(255,255,255,0.055)'}`,
        boxShadow: hov
          ? '0 0 25px rgba(255,102,0,0.18), 0 8px 30px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.07)'
          : '0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.04)',
        opacity: vis?1:0,
        transform: vis ? (hov?'translateY(-3px)':'translateY(0)') : 'translateY(18px) scale(0.96)',
        transition:`opacity 0.4s ${i*50}ms ease, transform 0.35s ${i*50}ms ease, border-color 0.2s, box-shadow 0.2s`,
        backdropFilter:'blur(8px)'
      }}>
      {/* Image area */}
      <div style={{ height:'122px', position:'relative', overflow:'hidden', background:'linear-gradient(135deg,rgba(15,8,4,1),rgba(5,5,15,1))' }}>
        {product.images?.[0] ? (
          <>
            <img src={product.images[0]} alt="" style={{ width:'100%', height:'100%', objectFit:'cover', opacity:0.85 }}/>
            <div style={{ position:'absolute', inset:0, background:'linear-gradient(to bottom,transparent 40%,rgba(0,0,0,0.5))' }}/>
          </>
        ) : (
          <div style={{ width:'100%', height:'100%', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <GameLogo title={product.title} game={product.game} category={product.category} size={64}/>
          </div>
        )}
        {/* Mirror highlight on card image */}
        <div style={{ position:'absolute', top:0, left:0, right:0, height:'35%', background:'linear-gradient(180deg,rgba(255,255,255,0.07),transparent)', pointerEvents:'none' }}/>

        {product.isPromoted && (
          <div style={{ position:'absolute', top:'7px', left:'7px',
            background:'linear-gradient(135deg,#ffe600,#ff8800)', color:'#000',
            fontSize:'9px', fontWeight:800, padding:'3px 8px', borderRadius:'100px',
            letterSpacing:'0.08em', fontFamily:'var(--font-d)',
            boxShadow:'0 0 10px rgba(255,200,0,0.5), inset 0 1px 0 rgba(255,255,255,0.3)' }}>
            ★ ТОП
          </div>
        )}
        <div style={{ position:'absolute', bottom:'7px', right:'7px',
          background:'rgba(0,0,0,0.82)', backdropFilter:'blur(8px)',
          border:'1px solid rgba(255,102,0,0.45)',
          color:'#ff8833', fontSize:'15px', fontWeight:800, padding:'4px 10px',
          borderRadius:'8px', fontFamily:'var(--font-d)',
          boxShadow:'0 0 12px rgba(255,102,0,0.3), inset 0 1px 0 rgba(255,255,255,0.1)',
          textShadow:'0 0 8px rgba(255,102,0,0.5)' }}>
          ${price.toFixed(2)}
        </div>
        {/* Category logo on image */}
        {!product.images?.[0] ? null : (
          <div style={{ position:'absolute', top:'7px', right:'7px' }}>
            <GameLogo title={product.title} game={product.game} category={product.category} size={26}/>
          </div>
        )}
      </div>

      {/* Info */}
      <div style={{ padding:'10px 11px' }}>
        <div style={{ fontSize:'13px', fontWeight:700, color:'var(--text)', lineHeight:'1.3', marginBottom:'7px',
          display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical', overflow:'hidden' }}>
          {product.title}
        </div>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div style={{ fontSize:'10px', color:'var(--text3)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', maxWidth:'65%' }}>
            {seller.username||seller.firstName||'Продавец'}
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:'3px', flexShrink:0 }}>
            <IC.Star s={11} c="#ffe600" filled/>
            <span style={{ fontSize:'11px', color:'#ffe600', fontWeight:700, textShadow:'0 0 5px rgba(255,230,0,0.4)' }}>
              {parseFloat(seller.rating||5).toFixed(1)}
            </span>
          </div>
        </div>
        <div style={{ marginTop:'5px' }}>
          <RubleAmount usd={price} size="sm"/>
        </div>
      </div>
    </div>
  )
}

function SkeletonCard({ i }) {
  return (
    <div style={{ borderRadius:'16px', overflow:'hidden', background:'rgba(11,11,15,0.9)', border:'1px solid rgba(255,255,255,0.04)' }}>
      <div className="skeleton" style={{ height:'122px' }}/>
      <div style={{ padding:'10px' }}>
        <div className="skeleton" style={{ height:'13px', marginBottom:'7px', borderRadius:'4px' }}/>
        <div className="skeleton" style={{ height:'11px', width:'60%', borderRadius:'4px' }}/>
      </div>
    </div>
  )
}

function Empty() {
  return (
    <div style={{ gridColumn:'1/-1', textAlign:'center', padding:'60px 20px' }}>
      <IC.Search s={48} c="rgba(255,255,255,0.08)"/>
      <div style={{ fontFamily:'var(--font-d)', fontSize:'20px', fontWeight:700, color:'var(--text3)', marginTop:'14px', letterSpacing:'0.08em' }}>
        НИЧЕГО НЕ НАЙДЕНО
      </div>
    </div>
  )
}
