import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore, api } from '../store'
import toast from 'react-hot-toast'
import GameBackground from '../components/GameBackground'

export default function AuthPage() {
  const navigate = useNavigate()
  const { login } = useStore()
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ email:'', password:'', username:'' })
  const [loading, setLoading] = useState(false)
  const set = (k,v) => setForm(f=>({...f,[k]:v}))

  const submit = async () => {
    if (!form.email||!form.password) return toast.error('Заполните все поля')
    setLoading(true)
    try {
      const { data } = await api.post(mode==='login'?'/auth/login':'/auth/register', form)
      login(data.token, data.user)
      navigate('/')
    } catch(e) { toast.error(e.response?.data?.error||'Ошибка') }
    setLoading(false)
  }

  return (
    <div style={{ height:'100vh', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'20px', position:'relative', overflow:'hidden' }}>
      <GameBackground/>

      <div style={{ position:'relative', zIndex:10, width:'100%', maxWidth:'380px' }}>
        {/* Logo */}
        <div style={{ textAlign:'center', marginBottom:'32px' }}>
          <div style={{
            fontFamily:'var(--font-d)', fontSize:'48px', fontWeight:700,
            background:'linear-gradient(135deg,#ff6600,#ff4400,#ff8800)',
            WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent',
            filter:'drop-shadow(0 0 15px rgba(255,102,0,0.6))',
            letterSpacing:'0.05em', animation:'neonFlicker 4s infinite'
          }}>GIVIHUB</div>
          <div style={{ color:'rgba(255,102,0,0.6)', fontSize:'11px', letterSpacing:'0.2em', fontFamily:'var(--font-d)', marginTop:'-4px' }}>
            DIGITAL MARKETPLACE
          </div>
          <div style={{ width:'80px', height:'2px', background:'linear-gradient(90deg,transparent,#ff6600,transparent)', margin:'10px auto 0', boxShadow:'0 0 10px rgba(255,102,0,0.5)' }}/>
        </div>

        {/* Card */}
        <div style={{
          background:'rgba(10,10,10,0.9)', backdropFilter:'blur(20px)',
          border:'1px solid rgba(255,102,0,0.25)', borderRadius:'18px', padding:'24px',
          boxShadow:'0 0 40px rgba(255,102,0,0.1), 0 20px 60px rgba(0,0,0,0.5)'
        }}>
          {/* Mode tabs */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'6px', marginBottom:'22px',
            background:'rgba(255,255,255,0.03)', borderRadius:'10px', padding:'4px' }}>
            {[['login','🔑 ВОЙТИ'],['register','✨ РЕГИСТРАЦИЯ']].map(([m,label])=>(
              <button key={m} onClick={()=>setMode(m)} style={{
                padding:'10px', borderRadius:'7px', border:'none', cursor:'pointer',
                background: mode===m ? 'linear-gradient(135deg,rgba(255,102,0,0.3),rgba(255,68,0,0.2))' : 'transparent',
                color: mode===m ? '#ff8833' : 'var(--text3)',
                fontFamily:'var(--font-d)', fontWeight:700, fontSize:'13px', letterSpacing:'0.05em',
                boxShadow: mode===m ? '0 0 12px rgba(255,102,0,0.2)' : 'none',
                border: mode===m ? '1px solid rgba(255,102,0,0.3)' : '1px solid transparent',
                transition:'all var(--ease)'
              }}>{label}</button>
            ))}
          </div>

          {mode==='register' && (
            <div style={{ marginBottom:'14px' }}>
              <label style={lbl}>Имя пользователя</label>
              <input className="input" placeholder="username" value={form.username} onChange={e=>set('username',e.target.value)}/>
            </div>
          )}

          <div style={{ marginBottom:'14px' }}>
            <label style={lbl}>Email</label>
            <input className="input" type="email" placeholder="your@email.com" value={form.email} onChange={e=>set('email',e.target.value)}/>
          </div>

          <div style={{ marginBottom:'22px' }}>
            <label style={lbl}>Пароль</label>
            <input className="input" type="password" placeholder="••••••••" value={form.password}
              onChange={e=>set('password',e.target.value)} onKeyDown={e=>e.key==='Enter'&&submit()}/>
          </div>

          <button className="btn btn-primary btn-full btn-lg" onClick={submit} disabled={loading}
            style={{ fontFamily:'var(--font-d)', fontSize:'16px', letterSpacing:'0.08em' }}>
            {loading ? '⏳ ЗАГРУЗКА...' : mode==='login' ? '🔑 ВОЙТИ' : '🚀 СОЗДАТЬ АККАУНТ'}
          </button>
        </div>

        <div style={{ textAlign:'center', marginTop:'16px', fontSize:'12px', color:'rgba(255,255,255,0.2)', letterSpacing:'0.05em' }}>
          🛡 БЕЗОПАСНЫЙ ВХОД · ДАННЫЕ ЗАЩИЩЕНЫ
        </div>
      </div>
    </div>
  )
}
const lbl = { display:'block', fontSize:'11px', fontWeight:600, color:'rgba(255,102,0,0.7)', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:'7px', fontFamily:'var(--font-d)' }
