import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore, api } from '../store'
import GameLogo from '../components/GameLogo'

const DEAL_STATUS = {
  frozen:    { l:'❄ ЗАМОРОЖЕНО', c:'#00d4ff', bg:'rgba(0,212,255,0.1)' },
  completed: { l:'✅ ЗАВЕРШЕНО',  c:'#00ff88', bg:'rgba(0,255,136,0.1)' },
  disputed:  { l:'⚠ СПОР',       c:'#ffe600', bg:'rgba(255,230,0,0.1)' },
  cancelled: { l:'❌ ОТМЕНЕНО',   c:'#ff3355', bg:'rgba(255,51,85,0.1)' },
  refunded:  { l:'↩ ВОЗВРАТ',    c:'#00d4ff', bg:'rgba(0,212,255,0.1)' },
}

export default function ProfilePage() {
  const navigate = useNavigate()
  const { user, logout } = useStore()
  const [deals, setDeals] = useState([])
  const [listings, setListings] = useState([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState('deals')

  useEffect(() => {
    Promise.all([api.get('/deals/my'), api.get('/products/my/listings')])
      .then(([d,l]) => { setDeals(d.data||[]); setListings(l.data||[]); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const buys = deals.filter(d=>d.buyerId===user?.id)
  const sells = deals.filter(d=>d.sellerId===user?.id)
  const name = user?.firstName||user?.username||'Пользователь'

  const TABS = [
    {id:'deals',label:'СДЕЛКИ',count:deals.length},
    {id:'purchases',label:'ПОКУПКИ',count:buys.length},
    {id:'sales',label:'ПРОДАЖИ',count:sells.length},
    {id:'listings',label:'МОИ ТОВАРЫ',count:listings.length},
  ]

  return (
    <div style={{minHeight:'100%'}}>
      {/* Header */}
      <div style={{padding:'16px 14px 0',background:'rgba(8,8,8,0.92)',borderBottom:'1px solid rgba(255,102,0,0.15)',backdropFilter:'blur(20px)'}}>

        {/* Profile card */}
        <div style={{display:'flex',alignItems:'center',gap:'14px',marginBottom:'16px'}}>
          <div style={{position:'relative',flexShrink:0}}>
            <div style={{width:'62px',height:'62px',borderRadius:'18px',overflow:'hidden',
              background:'linear-gradient(135deg,#ff6600,#ff4400)',
              display:'flex',alignItems:'center',justifyContent:'center',
              fontSize:'24px',fontWeight:800,color:'white',
              boxShadow:'0 0 25px rgba(255,102,0,0.4)',
              border:'2px solid rgba(255,102,0,0.4)'}}>
              {user?.photoUrl?<img src={user.photoUrl} style={{width:'100%',height:'100%',objectFit:'cover'}} alt=""/>
                :name.charAt(0).toUpperCase()}
            </div>
            {user?.isVerified && (
              <div style={{position:'absolute',bottom:'-3px',right:'-3px',width:'20px',height:'20px',borderRadius:'50%',
                background:'linear-gradient(135deg,#00d4ff,#0088aa)',
                display:'flex',alignItems:'center',justifyContent:'center',
                fontSize:'10px',color:'white',border:'2px solid var(--bg)',
                boxShadow:'0 0 8px rgba(0,212,255,0.5)'}}>✓</div>
            )}
          </div>
          <div style={{flex:1}}>
            <div style={{fontFamily:'var(--font-d)',fontSize:'20px',fontWeight:700,color:'var(--text)',letterSpacing:'0.02em'}}>{name}</div>
            <div style={{fontSize:'12px',color:'var(--text3)',marginTop:'2px'}}>
              {user?.username?`@${user.username}`:''}{user?.email?` · ${user.email}`:''}
            </div>
            <div style={{display:'flex',gap:'6px',marginTop:'6px',flexWrap:'wrap'}}>
              {user?.isAdmin && (
                <span style={{fontSize:'10px',background:'rgba(255,230,0,0.15)',color:'#ffe600',padding:'3px 9px',borderRadius:'100px',fontFamily:'var(--font-d)',fontWeight:700,letterSpacing:'0.06em',border:'1px solid rgba(255,230,0,0.3)',boxShadow:'0 0 8px rgba(255,230,0,0.2)'}}>
                  👑 ADMIN
                </span>
              )}
              {user?.isVerified && (
                <span style={{fontSize:'10px',background:'rgba(0,212,255,0.12)',color:'#00d4ff',padding:'3px 9px',borderRadius:'100px',fontFamily:'var(--font-d)',fontWeight:700,letterSpacing:'0.06em',border:'1px solid rgba(0,212,255,0.25)'}}>
                  ✓ ВЕРИФИЦИРОВАН
                </span>
              )}
            </div>
          </div>
          <button onClick={logout} style={{background:'rgba(255,51,85,0.1)',border:'1px solid rgba(255,51,85,0.25)',borderRadius:'10px',padding:'8px',cursor:'pointer',fontSize:'18px',boxShadow:'0 0 8px rgba(255,51,85,0.1)'}}>🚪</button>
        </div>

        {/* Stats */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'8px',marginBottom:'14px'}}>
          {[
            {v:`$${parseFloat(user?.balance||0).toFixed(0)}`,l:'БАЛАНС',c:'#ff8833'},
            {v:user?.totalSales||0,l:'ПРОДАЖ',c:'#00ff88'},
            {v:user?.totalPurchases||0,l:'ПОКУПОК',c:'#00d4ff'},
            {v:`${parseFloat(user?.rating||5).toFixed(1)}★`,l:'РЕЙТИНГ',c:'#ffe600'},
          ].map(s=>(
            <div key={s.l} style={{background:'rgba(255,255,255,0.03)',border:`1px solid ${s.c}20`,borderRadius:'10px',padding:'10px 6px',textAlign:'center',boxShadow:`0 0 10px ${s.c}10`}}>
              <div style={{fontFamily:'var(--font-d)',fontWeight:700,fontSize:'15px',color:s.c,textShadow:`0 0 8px ${s.c}60`}}>{s.v}</div>
              <div style={{fontSize:'9px',color:'var(--text3)',marginTop:'2px',letterSpacing:'0.06em',fontFamily:'var(--font-d)'}}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* Admin shortcut */}
        {user?.isAdmin && (
          <div onClick={()=>navigate('/admin')} style={{
            marginBottom:'12px',borderRadius:'12px',padding:'12px 14px',cursor:'pointer',
            background:'rgba(255,230,0,0.08)',border:'1px solid rgba(255,230,0,0.25)',
            display:'flex',alignItems:'center',gap:'12px',
            boxShadow:'0 0 15px rgba(255,230,0,0.08)',transition:'all var(--ease)'
          }}>
            <span style={{fontSize:'22px'}}>👑</span>
            <div>
              <div style={{fontFamily:'var(--font-d)',fontWeight:700,fontSize:'14px',color:'#ffe600',letterSpacing:'0.05em',textShadow:'0 0 8px rgba(255,230,0,0.4)'}}>ПАНЕЛЬ АДМИНИСТРАТОРА</div>
              <div style={{fontSize:'11px',color:'var(--text3)'}}>Управление пользователями, сделками, товарами</div>
            </div>
            <span style={{marginLeft:'auto',color:'#ffe600',fontSize:'18px'}}>→</span>
          </div>
        )}

        {/* Tabs */}
        <div style={{display:'flex',gap:'0',overflowX:'auto',scrollbarWidth:'none'}}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{
              padding:'10px 12px',whiteSpace:'nowrap',background:'none',border:'none',
              borderBottom:`2px solid ${tab===t.id?'var(--accent)':'transparent'}`,
              color:tab===t.id?'var(--accent)':'var(--text3)',
              fontFamily:'var(--font-d)',fontWeight:700,fontSize:'12px',
              letterSpacing:'0.05em',cursor:'pointer',transition:'all var(--ease)',
              textShadow:tab===t.id?'0 0 8px rgba(255,102,0,0.5)':'none'
            }}>
              {t.label}{t.count>0&&<span style={{marginLeft:'5px',background:tab===t.id?'var(--accent)':'rgba(255,255,255,0.08)',color:tab===t.id?'white':'var(--text3)',borderRadius:'100px',padding:'1px 6px',fontSize:'10px'}}>{t.count}</span>}
            </button>
          ))}
        </div>
      </div>

      <div style={{padding:'12px 14px'}}>
        {loading ? (
          Array(3).fill(0).map((_,i)=><div key={i} className="skeleton" style={{height:'80px',borderRadius:'12px',marginBottom:'8px'}}/>)
        ) : (
          <>
            {tab==='deals'&&<DealList deals={deals} userId={user?.id}/>}
            {tab==='purchases'&&<DealList deals={buys} userId={user?.id}/>}
            {tab==='sales'&&<DealList deals={sells} userId={user?.id}/>}
            {tab==='listings'&&<ListingList listings={listings}/>}
          </>
        )}
      </div>
    </div>
  )
}

function DealList({ deals, userId }) {
  const navigate = useNavigate()
  if (!deals.length) return <Empty label="НЕТ СДЕЛОК" icon="🤝"/>
  return (
    <div>
      {deals.map((deal,i)=>{
        const isBuyer = deal.buyerId===userId
        const other = isBuyer?deal.seller:deal.buyer
        const st = DEAL_STATUS[deal.status]||{l:deal.status,c:'var(--text3)',bg:'var(--surface)'}
        return (
          <div key={deal.id} onClick={()=>navigate(`/deal/${deal.id}`)} style={{
            background:'rgba(14,14,14,0.9)',border:`1px solid ${st.c}20`,borderRadius:'14px',
            padding:'14px',marginBottom:'8px',cursor:'pointer',
            animation:`fadeIn 0.3s ${i*60}ms both`,
            transition:'border-color 0.2s,box-shadow 0.2s',
            boxShadow:`0 0 10px ${st.c}08`
          }}>
            <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:'8px'}}>
              <div style={{fontWeight:700,fontSize:'14px',color:'var(--text)',flex:1,marginRight:'10px'}}>
                {deal.product?.title||'Товар'}
              </div>
              <span style={{padding:'3px 10px',borderRadius:'100px',fontSize:'11px',fontWeight:700,
                fontFamily:'var(--font-d)',letterSpacing:'0.04em',
                color:st.c,background:st.bg,whiteSpace:'nowrap',
                boxShadow:`0 0 8px ${st.c}30`}}>
                {st.l}
              </span>
            </div>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <div style={{fontSize:'12px',color:'var(--text3)'}}>
                {isBuyer?'🛒 Покупка у':'💸 Продажа'} {other?.username||other?.firstName||''}
              </div>
              <div style={{fontFamily:'var(--font-d)',fontWeight:700,fontSize:'16px',
                color:isBuyer?'#ff3355':'#00ff88',
                textShadow:`0 0 8px ${isBuyer?'rgba(255,51,85,0.4)':'rgba(0,255,136,0.4)'}`}}>
                {isBuyer?'-':'+'}${parseFloat(isBuyer?deal.amount:deal.sellerAmount).toFixed(2)}
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

function ListingList({ listings }) {
  const navigate = useNavigate()
  if (!listings.length) return <Empty label="НЕТ ОБЪЯВЛЕНИЙ" icon="📦" sub="Нажмите + чтобы продать"/>
  const SC = { active:'#00ff88', frozen:'#00d4ff', sold:'#b44fff', moderation:'#ffe600', deleted:'#ff3355' }
  return (
    <div>
      {listings.map((p,i)=>(
        <div key={p.id} onClick={()=>navigate(`/product/${p.id}`)} style={{
          background:'rgba(14,14,14,0.9)',border:'1px solid rgba(255,255,255,0.05)',borderRadius:'14px',
          padding:'12px',marginBottom:'8px',display:'flex',alignItems:'center',gap:'12px',cursor:'pointer',
          animation:`fadeIn 0.3s ${i*60}ms both`
        }}>
          <GameLogo title={p.title} game={p.game} category={p.category} size={46}/>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontWeight:600,fontSize:'14px',color:'var(--text)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{p.title}</div>
            <div style={{fontSize:'11px',color:'var(--text3)',marginTop:'3px',display:'flex',gap:'8px'}}>
              <span style={{color:SC[p.status]||'var(--text3)',textShadow:`0 0 6px ${SC[p.status]||'transparent'}60`}}>● {p.status}</span>
              <span>👁 {p.views||0}</span>
            </div>
          </div>
          <div style={{fontFamily:'var(--font-d)',fontWeight:700,fontSize:'16px',color:'#ff8833',flexShrink:0,textShadow:'0 0 8px rgba(255,102,0,0.4)'}}>${parseFloat(p.price).toFixed(2)}</div>
        </div>
      ))}
    </div>
  )
}

function Empty({ label, icon, sub }) {
  return (
    <div style={{textAlign:'center',padding:'50px 20px'}}>
      <div style={{fontSize:'48px',marginBottom:'12px',animation:'float 3s ease-in-out infinite'}}>{icon}</div>
      <div style={{fontFamily:'var(--font-d)',fontSize:'18px',fontWeight:700,color:'var(--text3)',letterSpacing:'0.08em',marginBottom:'6px'}}>{label}</div>
      {sub&&<div style={{fontSize:'13px',color:'var(--text3)'}}>{sub}</div>}
    </div>
  )
}
