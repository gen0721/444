import React from 'react'
import { Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useStore } from '../store'
import GameBackground from './GameBackground'
import { IC } from './Icons'

export default function Layout() {
  const { user, theme, toggleTheme } = useStore()
  const navigate = useNavigate()
  const { pathname } = useLocation()

  const tabs = [
    { to:'/', label:'КАТАЛОГ', Icon: IC.Home },
    { to:'/wallet', label:'БАЛАНС', Icon: IC.Wallet },
    { to:'/create', special: true },
    { to:'/profile', label:'ПРОФИЛЬ', Icon: IC.User },
    ...(user?.isAdmin || user?.isSubAdmin ? [{ to:'/admin', label:'ПАНЕЛЬ', Icon: IC.Crown }] : [])
  ]

  return (
    <div style={{ height:'100vh', height:'100dvh', display:'flex', flexDirection:'column', background:'var(--bg)', position:'relative', overflow:'hidden' }}>
      <GameBackground />

      <div className="scrollable" style={{ flex:1, position:'relative', zIndex:2, paddingBottom:'68px' }}>
        <Outlet/>
      </div>

      {/* Bottom nav */}
      <nav style={{
        position:'fixed', bottom:0, left:0, right:0, zIndex:100,
        background:'rgba(6,6,8,0.96)',
        borderTop:'1px solid rgba(255,102,0,0.18)',
        backdropFilter:'blur(24px)', WebkitBackdropFilter:'blur(24px)',
        paddingBottom:'env(safe-area-inset-bottom,0px)',
        boxShadow:'0 -2px 30px rgba(0,0,0,0.6), 0 -1px 0 rgba(255,102,0,0.08)'
      }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-around', height:'56px', maxWidth:'520px', margin:'0 auto', padding:'0 4px' }}>
          {tabs.map((tab, i) => {
            const active = pathname === tab.to
            if (tab.special) return (
              <button key="create" onClick={()=>navigate('/create')} style={{
                display:'flex', alignItems:'center', justifyContent:'center',
                width:'52px', height:'52px', borderRadius:'15px',
                background:'linear-gradient(135deg,#ff6600,#cc3300)',
                border:'none', cursor:'pointer',
                color:'white', transform:'translateY(-10px)',
                boxShadow:'0 0 25px rgba(255,102,0,0.6), 0 0 50px rgba(255,102,0,0.2), 0 8px 20px rgba(0,0,0,0.5)',
                transition:'all 0.2s ease',
                position:'relative', overflow:'hidden'
              }}
              onMouseDown={e=>e.currentTarget.style.transform='translateY(-8px) scale(0.95)'}
              onMouseUp={e=>e.currentTarget.style.transform='translateY(-10px) scale(1)'}
              onTouchStart={e=>e.currentTarget.style.transform='translateY(-8px) scale(0.95)'}
              onTouchEnd={e=>e.currentTarget.style.transform='translateY(-10px) scale(1)'}
              >
                <div style={{ position:'absolute', inset:0, background:'linear-gradient(135deg,rgba(255,255,255,0.2),transparent)', borderRadius:'15px' }}/>
                <IC.Plus s={26} c="white"/>
              </button>
            )
            const { Icon } = tab
            return (
              <button key={tab.to} onClick={()=>navigate(tab.to)} style={{
                display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
                gap:'3px', flex:1, height:'100%', padding:'0',
                background:'none', border:'none', cursor:'pointer',
                transition:'all 0.2s ease', position:'relative',
                transform: active ? 'scale(1)' : 'scale(1)',
              }}>
                {active && (
                  <div style={{ position:'absolute', top:0, left:'50%', transform:'translateX(-50%)',
                    width:'24px', height:'2px', borderRadius:'0 0 2px 2px',
                    background:'linear-gradient(90deg,#ff6600,#ff8800)',
                    boxShadow:'0 0 8px rgba(255,102,0,0.8)' }}/>
                )}
                <div style={{
                  transform: active ? 'scale(1.1)' : 'scale(1)',
                  transition:'transform 0.25s cubic-bezier(0.34,1.56,0.64,1)',
                  color: active ? '#ff6600' : 'rgba(255,255,255,0.3)',
                  filter: active ? 'drop-shadow(0 0 4px rgba(255,102,0,0.6))' : 'none'
                }}>
                  <Icon s={21}/>
                </div>
                <span style={{
                  fontSize:'9px', fontWeight:700, letterSpacing:'0.07em',
                  color: active ? '#ff6600' : 'rgba(255,255,255,0.25)',
                  fontFamily:'var(--font-d)',
                  textShadow: active ? '0 0 8px rgba(255,102,0,0.5)' : 'none',
                  transition:'all 0.2s'
                }}>{tab.label}</span>
              </button>
            )
          })}
        </div>
      </nav>

      {/* Theme toggle */}
      <button onClick={toggleTheme} style={{
        position:'fixed', top:'12px', right:'12px', zIndex:200,
        width:'34px', height:'34px', borderRadius:'10px',
        background:'rgba(0,0,0,0.65)', border:'1px solid rgba(255,102,0,0.25)',
        cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
        backdropFilter:'blur(10px)', color:'rgba(255,255,255,0.7)',
        transition:'all 0.2s', boxShadow:'0 2px 10px rgba(0,0,0,0.4)'
      }}>
        {theme==='dark' ? <IC.Sun s={16}/> : <IC.Moon s={16}/>}
      </button>
    </div>
  )
}
