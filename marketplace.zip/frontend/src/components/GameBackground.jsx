import React, { useEffect, useRef, useState, useCallback } from 'react'

// Real game scenes with advanced canvas rendering
const SCENES = [
  {
    name: 'DOTA 2',
    bg: ['#0a0514', '#1a0a2e', '#0a0820', '#05020f'],
    primary: '#c8371a', secondary: '#ff6633', accent: '#ffd700',
    draw: (ctx, t, w, h) => {
      // Deep purple sky with hex grid
      const grad = ctx.createLinearGradient(0, 0, 0, h)
      grad.addColorStop(0, '#030108')
      grad.addColorStop(0.4, '#0d0520')
      grad.addColorStop(0.7, '#1a0808')
      grad.addColorStop(1, '#0a0404')
      ctx.fillStyle = grad
      ctx.fillRect(0, 0, w, h)

      // Hex grid pattern
      const hex = 40, hx = hex * Math.sqrt(3), hy = hex * 1.5
      ctx.strokeStyle = `rgba(200,55,26,${0.04 + 0.02 * Math.sin(t)})`
      ctx.lineWidth = 1
      for (let row = -1; row < h / hy + 2; row++) {
        for (let col = -1; col < w / hx + 2; col++) {
          const x = col * hx + (row % 2) * hx / 2
          const y = row * hy
          ctx.beginPath()
          for (let i = 0; i < 6; i++) {
            const angle = (Math.PI / 3) * i - Math.PI / 6
            const px = x + hex * Math.cos(angle)
            const py = y + hex * Math.sin(angle)
            i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py)
          }
          ctx.closePath(); ctx.stroke()
        }
      }

      // Glowing horizon
      const horizon = ctx.createLinearGradient(0, h * 0.55, 0, h * 0.75)
      horizon.addColorStop(0, 'rgba(200,55,26,0.15)')
      horizon.addColorStop(1, 'transparent')
      ctx.fillStyle = horizon
      ctx.fillRect(0, h * 0.55, w, h * 0.2)

      // Roshan tower silhouette
      const tx = w * 0.5, ty = h * 0.45
      ctx.fillStyle = 'rgba(10,5,20,0.9)'
      ctx.beginPath()
      ctx.moveTo(tx - 30, h); ctx.lineTo(tx - 30, ty + 20)
      ctx.lineTo(tx - 20, ty); ctx.lineTo(tx - 10, ty - 15)
      ctx.lineTo(tx, ty - 25); ctx.lineTo(tx + 10, ty - 15)
      ctx.lineTo(tx + 20, ty); ctx.lineTo(tx + 30, ty + 20)
      ctx.lineTo(tx + 30, h); ctx.fill()

      // Pulsing glow at tower top
      const glowR = 25 + 10 * Math.sin(t * 2)
      const g = ctx.createRadialGradient(tx, ty - 25, 0, tx, ty - 25, glowR)
      g.addColorStop(0, 'rgba(200,55,26,0.6)')
      g.addColorStop(1, 'transparent')
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h)

      // Floating runes
      for (let i = 0; i < 5; i++) {
        const rx = w * (0.1 + i * 0.2) + Math.sin(t + i) * 20
        const ry = h * 0.7 + Math.cos(t * 0.7 + i) * 15
        const alpha = 0.3 + 0.3 * Math.sin(t * 1.5 + i)
        ctx.fillStyle = `rgba(255,200,50,${alpha})`
        ctx.font = '16px serif'
        ctx.fillText(['⬡','◈','✦','⊕','◇'][i], rx, ry)
      }
    }
  },
  {
    name: 'GTA V',
    bg: ['#0a1520', '#0f1e30', '#060e18', '#0a0f1a'],
    primary: '#fcaf17', secondary: '#ff8800', accent: '#ffffff',
    draw: (ctx, t, w, h) => {
      // Night city sky
      const sky = ctx.createLinearGradient(0, 0, 0, h)
      sky.addColorStop(0, '#020810')
      sky.addColorStop(0.5, '#0a1525')
      sky.addColorStop(0.7, '#101a10')
      sky.addColorStop(1, '#0a0a08')
      ctx.fillStyle = sky; ctx.fillRect(0, 0, w, h)

      // City skyline silhouette
      const buildings = [
        {x:0.05,w:0.06,h:0.4,win:[[0.1,0.15],[0.5,0.2],[0.1,0.4],[0.5,0.45]]},
        {x:0.12,w:0.08,h:0.55,win:[[0.2,0.1],[0.6,0.15],[0.2,0.3],[0.6,0.35]]},
        {x:0.22,w:0.1,h:0.45,win:[[0.15,0.2],[0.5,0.25],[0.15,0.4]]},
        {x:0.35,w:0.12,h:0.65,win:[[0.1,0.08],[0.4,0.12],[0.7,0.08],[0.1,0.25],[0.4,0.3],[0.7,0.25]]},
        {x:0.5,w:0.07,h:0.38,win:[[0.2,0.2],[0.6,0.25]]},
        {x:0.6,w:0.11,h:0.58,win:[[0.15,0.1],[0.5,0.15],[0.8,0.1],[0.15,0.3]]},
        {x:0.73,w:0.09,h:0.42,win:[[0.2,0.2],[0.6,0.25],[0.2,0.4]]},
        {x:0.84,w:0.08,h:0.52,win:[[0.15,0.12],[0.5,0.18],[0.15,0.32]]},
        {x:0.93,w:0.07,h:0.36,win:[[0.3,0.2],[0.7,0.25]]},
      ]
      buildings.forEach(b => {
        const bx = b.x * w, bw = b.w * w, bh = b.h * h, by = h * (1 - b.h)
        ctx.fillStyle = '#050d15'
        ctx.fillRect(bx, by, bw, bh)
        b.win.forEach(([wx,wy]) => {
          const alpha = 0.5 + 0.5 * Math.sin(t * 0.3 + wx * 10 + wy * 5)
          const isOn = Math.sin(t * 0.1 + wx * 20 + wy * 15) > -0.3
          if (isOn) {
            ctx.fillStyle = `rgba(255,230,100,${alpha * 0.8})`
            ctx.fillRect(bx + wx * bw, by + wy * bh, bw * 0.12, bh * 0.08)
          }
        })
      })

      // Moving car headlights/taillights
      for (let i = 0; i < 4; i++) {
        const cx = ((t * 60 * (i % 2 === 0 ? 1 : -1) + i * 200) % (w + 100)) - 50
        const cy = h * (0.82 + i * 0.04)
        const isRight = i % 2 === 0
        ctx.fillStyle = isRight ? 'rgba(255,230,150,0.9)' : 'rgba(255,50,50,0.9)'
        ctx.beginPath(); ctx.arc(cx + (isRight ? 0 : 20), cy, 2, 0, Math.PI * 2); ctx.fill()
        ctx.beginPath(); ctx.arc(cx + (isRight ? 12 : 8), cy, 2, 0, Math.PI * 2); ctx.fill()
        // Light beam
        const beamGrad = ctx.createLinearGradient(cx, cy, cx + (isRight ? -60 : 60), cy)
        beamGrad.addColorStop(0, isRight ? 'rgba(255,230,150,0.3)' : 'rgba(255,50,50,0.2)')
        beamGrad.addColorStop(1, 'transparent')
        ctx.fillStyle = beamGrad
        ctx.fillRect(cx + (isRight ? -60 : 20), cy - 3, 60, 6)
      }

      // Street glow
      const street = ctx.createLinearGradient(0, h * 0.85, 0, h)
      street.addColorStop(0, 'rgba(252,175,23,0.08)'); street.addColorStop(1, 'transparent')
      ctx.fillStyle = street; ctx.fillRect(0, h * 0.85, w, h * 0.15)
    }
  },
  {
    name: 'CS2',
    bg: ['#040810', '#08101a', '#050c14', '#030608'],
    primary: '#e4c84b', secondary: '#b89a2a', accent: '#00d4ff',
    draw: (ctx, t, w, h) => {
      // Dark tactical map
      const bg = ctx.createLinearGradient(0, 0, w, h)
      bg.addColorStop(0, '#030608'); bg.addColorStop(1, '#080c10')
      ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h)

      // Grid overlay
      ctx.strokeStyle = `rgba(228,200,75,0.04)`; ctx.lineWidth = 1
      for (let x = 0; x < w; x += 50) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke() }
      for (let y = 0; y < h; y += 50) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke() }

      // Map layout boxes (Dust2 inspired)
      const rooms = [
        [0.1,0.2,0.25,0.3],[0.4,0.1,0.25,0.2],[0.7,0.2,0.2,0.3],
        [0.2,0.55,0.3,0.25],[0.55,0.5,0.25,0.3],
      ]
      rooms.forEach(([rx,ry,rw,rh]) => {
        ctx.strokeStyle = `rgba(228,200,75,${0.08 + 0.03*Math.sin(t+rx*10)})`
        ctx.lineWidth = 1.5
        ctx.strokeRect(rx*w, ry*h, rw*w, rh*h)
        ctx.fillStyle = `rgba(228,200,75,0.02)`
        ctx.fillRect(rx*w, ry*h, rw*w, rh*h)
      })

      // Crosshair in center
      const cx = w/2, cy = h/2
      const cr = 20 + 5*Math.sin(t*3)
      ctx.strokeStyle = `rgba(0,212,255,${0.4+0.2*Math.sin(t*2)})`; ctx.lineWidth = 1.5
      ctx.beginPath(); ctx.moveTo(cx-cr-8,cy); ctx.lineTo(cx-4,cy); ctx.stroke()
      ctx.beginPath(); ctx.moveTo(cx+4,cy); ctx.lineTo(cx+cr+8,cy); ctx.stroke()
      ctx.beginPath(); ctx.moveTo(cx,cy-cr-8); ctx.lineTo(cx,cy-4); ctx.stroke()
      ctx.beginPath(); ctx.moveTo(cx,cy+4); ctx.lineTo(cx,cy+cr+8); ctx.stroke()
      ctx.beginPath(); ctx.arc(cx,cy,2,0,Math.PI*2); ctx.fillStyle='rgba(0,212,255,0.6)'; ctx.fill()

      // Radar dots (players)
      const players = [
        {x:0.22,y:0.35,team:true},{x:0.25,y:0.38,team:true},{x:0.28,y:0.33,team:true},
        {x:0.72,y:0.65,team:false},{x:0.68,y:0.62,team:false}
      ]
      players.forEach(p => {
        const px = p.x*w + Math.sin(t+p.x*10)*3
        const py = p.y*h + Math.cos(t+p.y*10)*3
        ctx.beginPath(); ctx.arc(px,py,5,0,Math.PI*2)
        ctx.fillStyle = p.team ? `rgba(100,200,100,0.8)` : `rgba(255,80,80,0.8)`
        ctx.fill()
        ctx.strokeStyle = p.team ? 'rgba(100,255,100,0.5)' : 'rgba(255,100,100,0.5)'
        ctx.lineWidth = 1; ctx.stroke()
      })
    }
  },
  {
    name: 'FORTNITE',
    bg: ['#0a1a3a', '#1d4dbd', '#0a0a2a', '#051030'],
    primary: '#00d4ff', secondary: '#9d4dca', accent: '#ffe600',
    draw: (ctx, t, w, h) => {
      // Vibrant storm sky
      const sky = ctx.createLinearGradient(0, 0, 0, h)
      sky.addColorStop(0, '#0a0520')
      sky.addColorStop(0.3, '#1a1555')
      sky.addColorStop(0.6, '#2a3590')
      sky.addColorStop(0.8, '#1a5080')
      sky.addColorStop(1, '#0a1520')
      ctx.fillStyle = sky; ctx.fillRect(0, 0, w, h)

      // Storm circle
      const scx = w * 0.55 + Math.sin(t * 0.2) * 20
      const scy = h * 0.4
      const sr = Math.min(w,h) * (0.3 + 0.05*Math.sin(t*0.3))
      const stormGrad = ctx.createRadialGradient(scx,scy,sr*0.7,scx,scy,sr)
      stormGrad.addColorStop(0, 'transparent')
      stormGrad.addColorStop(0.8, 'transparent')
      stormGrad.addColorStop(0.9, 'rgba(100,0,200,0.15)')
      stormGrad.addColorStop(1, 'rgba(150,50,255,0.4)')
      ctx.fillStyle = stormGrad; ctx.fillRect(0,0,w,h)

      // Storm ring glow
      ctx.beginPath(); ctx.arc(scx,scy,sr,0,Math.PI*2)
      ctx.strokeStyle = `rgba(160,80,255,${0.3+0.2*Math.sin(t*2)})`
      ctx.lineWidth = 3; ctx.stroke()

      // Lightning
      if (Math.sin(t * 7) > 0.96) {
        const lx = w * (0.2 + Math.random() * 0.6)
        ctx.strokeStyle = 'rgba(200,180,255,0.9)'; ctx.lineWidth = 2
        ctx.beginPath(); ctx.moveTo(lx, 0)
        ctx.lineTo(lx + (Math.random()-0.5)*30, h*0.3)
        ctx.lineTo(lx + (Math.random()-0.5)*40, h*0.5)
        ctx.lineTo(lx + (Math.random()-0.5)*20, h*0.65)
        ctx.stroke()
      }

      // Floating island
      ctx.fillStyle = '#2a4a1a'
      ctx.beginPath()
      ctx.ellipse(w*0.3, h*0.55, 80, 25, -0.1, 0, Math.PI*2)
      ctx.fill()
      ctx.fillStyle = '#1a3010'
      ctx.beginPath()
      ctx.ellipse(w*0.3, h*0.56, 80, 18, -0.1, 0, Math.PI)
      ctx.fill()
      // Trees on island
      [w*0.2,w*0.27,w*0.33,w*0.38].forEach((tx,i) => {
        const th = 18 + i*3
        ctx.fillStyle = '#1a5020'
        ctx.beginPath()
        ctx.moveTo(tx, h*0.55-th); ctx.lineTo(tx-8, h*0.53); ctx.lineTo(tx+8, h*0.53)
        ctx.closePath(); ctx.fill()
      })

      // Battle bus path arc
      const busx = (t * 50) % (w + 200) - 100
      ctx.fillStyle = 'rgba(255,230,0,0.8)'
      ctx.beginPath(); ctx.ellipse(busx, h*0.2, 22, 10, 0, 0, Math.PI*2); ctx.fill()
      ctx.fillStyle = 'rgba(100,180,255,0.6)'
      ctx.beginPath(); ctx.ellipse(busx, h*0.2-6, 12, 6, 0, 0, Math.PI*2); ctx.fill()
      // Bus trail
      const trailGrad = ctx.createLinearGradient(busx-100, 0, busx, 0)
      trailGrad.addColorStop(0,'transparent'); trailGrad.addColorStop(1,'rgba(100,200,255,0.2)')
      ctx.strokeStyle = trailGrad; ctx.lineWidth = 2
      ctx.beginPath(); ctx.moveTo(busx-100,h*0.2); ctx.lineTo(busx,h*0.2); ctx.stroke()
    }
  },
  {
    name: 'VALORANT',
    bg: ['#0d0810', '#180a0a', '#0d0510', '#050308'],
    primary: '#ff4655', secondary: '#bd3944', accent: '#ffffff',
    draw: (ctx, t, w, h) => {
      const bg = ctx.createLinearGradient(0,0,0,h)
      bg.addColorStop(0,'#030105'); bg.addColorStop(0.5,'#0d0208'); bg.addColorStop(1,'#050103')
      ctx.fillStyle=bg; ctx.fillRect(0,0,w,h)

      // Diagonal slashes
      for(let i=0;i<6;i++){
        const sx = (t*30+i*(w/5)) % (w+200) - 100
        const alpha = 0.03 + 0.02*Math.sin(t+i)
        ctx.strokeStyle=`rgba(255,70,85,${alpha})`; ctx.lineWidth=60
        ctx.beginPath(); ctx.moveTo(sx,0); ctx.lineTo(sx+100,h); ctx.stroke()
      }

      // Agent silhouette (Jett)
      const ax = w*0.5, ay = h*0.45
      ctx.fillStyle = 'rgba(5,2,8,0.95)'
      ctx.beginPath()
      // Body
      ctx.ellipse(ax,ay+30,15,25,0,0,Math.PI*2); ctx.fill()
      // Head
      ctx.beginPath(); ctx.arc(ax,ay-10,14,0,Math.PI*2); ctx.fill()
      // Blade trail
      const bx = ax+20+15*Math.sin(t*3), by = ay-5+10*Math.cos(t*2.5)
      const blade = ctx.createLinearGradient(ax,ay,bx,by)
      blade.addColorStop(0,'rgba(255,70,85,0.8)'); blade.addColorStop(1,'transparent')
      ctx.strokeStyle=blade; ctx.lineWidth=3
      ctx.beginPath(); ctx.moveTo(ax,ay); ctx.lineTo(bx,by); ctx.stroke()
      // Glow around agent
      const aGlow = ctx.createRadialGradient(ax,ay,0,ax,ay,60)
      aGlow.addColorStop(0,'rgba(255,70,85,0.1)'); aGlow.addColorStop(1,'transparent')
      ctx.fillStyle=aGlow; ctx.fillRect(0,0,w,h)

      // Spike bomb
      const spx = w*0.7+10*Math.sin(t), spy = h*0.72
      const spPulse = 0.4+0.4*Math.sin(t*4)
      ctx.fillStyle=`rgba(255,70,85,${spPulse})`
      ctx.beginPath(); ctx.arc(spx,spy,8,0,Math.PI*2); ctx.fill()
      ctx.strokeStyle=`rgba(255,70,85,${spPulse*0.5})`; ctx.lineWidth=3
      ctx.beginPath(); ctx.arc(spx,spy,16,0,Math.PI*2); ctx.stroke()
      // Beep circles
      const beepR = 16+30*((t*1.5)%1)
      ctx.strokeStyle=`rgba(255,70,85,${Math.max(0,0.5-((t*1.5)%1)*0.5)})`
      ctx.lineWidth=1.5; ctx.beginPath(); ctx.arc(spx,spy,beepR,0,Math.PI*2); ctx.stroke()
    }
  },
  {
    name: 'MINECRAFT',
    bg: ['#1a2e3a', '#1a2a1a', '#0a1a0a', '#0f1f0f'],
    primary: '#5aad3b', secondary: '#7bc950', accent: '#a0d4e0',
    draw: (ctx, t, w, h) => {
      // Pixel day sky
      const sky = ctx.createLinearGradient(0,0,0,h*0.5)
      sky.addColorStop(0,'#5ba3e0'); sky.addColorStop(1,'#8dc9f0')
      ctx.fillStyle=sky; ctx.fillRect(0,0,w,h*0.5)

      // Blocky clouds
      const cloudX = (t*15)%(w+120)-60
      [[cloudX,h*0.12,80,24],[cloudX+200,h*0.08,60,20],[cloudX-150,h*0.15,70,22]].forEach(([cx,cy,cw,ch])=>{
        ctx.fillStyle='rgba(255,255,255,0.92)'
        // Pixelated cloud blocks
        for(let bx=0;bx<cw;bx+=8){
          for(let by=0;by<ch;by+=8){
            if((bx===0&&by===0)||(bx===cw-8&&by===0)||(bx===0&&by===ch-8)||(bx===cw-8&&by===ch-8)) continue
            ctx.fillRect(cx+bx,cy+by,8,8)
          }
        }
      })

      // Ground / terrain
      const BLOCK = 20
      const terrain = [4,4,3,3,4,4,3,2,2,3,3,4,4,5,5,4,4,3,3,4,4,3,3,4]
      terrain.forEach((h2,i)=>{
        const bx = i*BLOCK
        // Grass block
        ctx.fillStyle='#5aad3b'; ctx.fillRect(bx,h-h2*BLOCK,BLOCK,BLOCK)
        ctx.fillStyle='#3d7a25'; ctx.fillRect(bx,h-h2*BLOCK+2,BLOCK,BLOCK-2)
        // Dirt blocks below
        for(let d=1;d<h2;d++){
          const shade = d<2?'#8b5a2b':d<4?'#6b3a10':'#4a2808'
          ctx.fillStyle=shade; ctx.fillRect(bx,h-(h2-d)*BLOCK,BLOCK,BLOCK)
          ctx.strokeStyle='rgba(0,0,0,0.2)'; ctx.lineWidth=0.5
          ctx.strokeRect(bx,h-(h2-d)*BLOCK,BLOCK,BLOCK)
        }
      })

      // Steve character
      const sx = w*0.35+10*Math.sin(t*2), sy = h-6*BLOCK
      const frame = Math.floor(t*4)%2
      ctx.fillStyle='#f5c292'; ctx.fillRect(sx,sy,16,16) // head
      ctx.fillStyle='#1a6abf'; ctx.fillRect(sx-2,sy+16,20,20) // body
      ctx.fillStyle='#f5c292'; ctx.fillRect(sx-6,sy+17,8,18) // arm L
      ctx.fillStyle='#1a6abf'; ctx.fillRect(sx+14,sy+17,8,18) // arm R
      ctx.fillStyle='#5a3010'; ctx.fillRect(sx,sy+34,8,18+frame*2) // leg L
      ctx.fillStyle='#5a3010'; ctx.fillRect(sx+8,sy+34,8,18-frame*2) // leg R
      // Eyes
      ctx.fillStyle='#1a1a1a'; ctx.fillRect(sx+3,sy+5,3,3); ctx.fillRect(sx+10,sy+5,3,3)

      // Creeper far away
      const crx = w*0.7-20*Math.sin(t*0.5)
      ctx.fillStyle='#4a8a2a'; ctx.fillRect(crx,h-5*BLOCK,18,22); ctx.fillRect(crx-2,h-5*BLOCK-14,22,16)
      ctx.fillStyle='#1a1a1a'; ctx.fillRect(crx+3,h-5*BLOCK-12,5,5); ctx.fillRect(crx+12,h-5*BLOCK-12,5,5)
      ctx.fillRect(crx+6,h-5*BLOCK-6,8,3); ctx.fillRect(crx+4,h-5*BLOCK-3,3,3); ctx.fillRect(crx+12,h-5*BLOCK-3,3,3)
    }
  },
]

export default function GameBackground() {
  const canvasRef = useRef(null)
  const animRef = useRef(null)
  const timeRef = useRef(0)
  const [sceneIdx, setSceneIdx] = useState(0)
  const [transitioning, setTransitioning] = useState(false)
  const [opacity, setOpacity] = useState(1)
  const sceneRef = useRef(0)

  // Rotate scenes every 10 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setTransitioning(true)
      setOpacity(0)
      setTimeout(() => {
        setSceneIdx(i => { sceneRef.current = (i+1)%SCENES.length; return (i+1)%SCENES.length })
        setTimeout(() => { setOpacity(1); setTransitioning(false) }, 200)
      }, 500)
    }, 10000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight }
    resize()
    window.addEventListener('resize', resize)

    const animate = () => {
      timeRef.current += 0.016
      const scene = SCENES[sceneRef.current]
      scene.draw(ctx, timeRef.current, canvas.width, canvas.height)
      // Vignette
      const vig = ctx.createRadialGradient(canvas.width/2,canvas.height/2,canvas.height*0.2,canvas.width/2,canvas.height/2,canvas.width*0.85)
      vig.addColorStop(0,'transparent'); vig.addColorStop(1,'rgba(0,0,0,0.7)')
      ctx.fillStyle=vig; ctx.fillRect(0,0,canvas.width,canvas.height)
      animRef.current = requestAnimationFrame(animate)
    }
    animate()
    return () => { cancelAnimationFrame(animRef.current); window.removeEventListener('resize',resize) }
  }, [])

  const scene = SCENES[sceneIdx]

  return (
    <>
      <canvas ref={canvasRef} style={{ position:'fixed', inset:0, zIndex:0, opacity: opacity * 0.65, transition:'opacity 0.5s ease' }}/>
      {/* Scene indicator */}
      <div style={{
        position:'fixed', bottom:'70px', right:'10px', zIndex:5,
        background:'rgba(0,0,0,0.7)', backdropFilter:'blur(12px)',
        border:`1px solid ${scene.primary}40`,
        borderRadius:'8px', padding:'4px 10px',
        fontSize:'10px', fontWeight:700, color:scene.primary,
        letterSpacing:'0.1em', fontFamily:'var(--font-d)',
        boxShadow:`0 0 12px ${scene.primary}25`,
        transition:'all 0.5s ease'
      }}>
        ▶ {scene.name}
      </div>
    </>
  )
}
