/**
 * Safe migration — drops old broken tables, recreates them cleanly.
 * Runs ONCE before server starts.
 */
require('dotenv').config();
const sequelize = require('./db');

async function migrate() {
  try {
    await sequelize.authenticate();
    console.log('✅ DB connected for migration');

    // Drop all tables in correct order (foreign keys)
    await sequelize.query(`
      DROP TABLE IF EXISTS "favorites" CASCADE;
      DROP TABLE IF EXISTS "transactions" CASCADE;
      DROP TABLE IF EXISTS "deals" CASCADE;
      DROP TABLE IF EXISTS "products" CASCADE;
      DROP TABLE IF EXISTS "users" CASCADE;
      DROP TYPE IF EXISTS "enum_products_status" CASCADE;
      DROP TYPE IF EXISTS "enum_deals_status" CASCADE;
      DROP TYPE IF EXISTS "enum_transactions_type" CASCADE;
      DROP TYPE IF EXISTS "enum_transactions_status" CASCADE;
    `);
    console.log('✅ Old tables dropped');

    // Now sync fresh
    const { User, Product, Deal, Transaction, Favorite } = require('./models/index');
    await sequelize.sync({ force: false });
    console.log('✅ Fresh tables created');

    // Create admin
    const adminTgId = process.env.ADMIN_TELEGRAM_ID;
    if (adminTgId) {
      await User.findOrCreate({
        where: { telegramId: String(adminTgId) },
        defaults: {
          telegramId: String(adminTgId),
          username: 'admin',
          firstName: 'Admin',
          isAdmin: true,
          isVerified: true
        }
      });
      console.log('✅ Admin created:', adminTgId);
    }

    console.log('✅ Migration complete!');
    process.exit(0);
  } catch (err) {
    console.error('❌ Migration failed:', err.message);
    process.exit(1);
  }
}

migrate();
